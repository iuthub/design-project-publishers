<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|ss
*/

// Route::get('/', function () {
//     return view('welcome');
// });
// Route::get('/', 'BookController@index');
Route::get('/home', 'BookController@index');
Route::get('/contact', 'BookController@contact');
Route::get('/freebook', 'BookController@free');
Route::get('/detail/{id}', 'BookController@detail');
Route::get('/admin/{id}/edit/', 'PostController@edit');
Route::post('/updated/{id}', 'PostController@update');
Route::resource('admin', 'PostController');
Route::resource('category', 'CategoryController');
Route::get('/register', 'RegistrationController@create');
Route::post('register', 'RegistrationController@store');
Route::get('/', 'SessionsController@create');
Route::post('loginman', 'SessionsController@store');
Route::get('/logout', 'SessionsController@destroy');
Route::get('/adminhome', 'BookController@adminhome');
