@extends('admin/index')
@section('content')
<br>
@foreach($category as $cat)
<hr>
                <h3>Category name: {{$cat->name}} </h3>
                @endforeach

@endsection