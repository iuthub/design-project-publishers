
@extends('admin/index')
@section('content')
  <div class="container">
  <div id="templatemo_content_right">
            <div class="templatemo_product_box">
              @foreach($books as $book)
                <h6 style="margin-left: 40px">Book NAme: {{$book->name}} <br> <span> Author: {{$book->author}}</span></h6>
                  <ul style=" list-style-type: none;">
                    <li style="float: left; padding-right: 10px"> <img src="uploads/{{$book->profile_image}}" alt="image" />
                    </li>
                    <li><div class="product_info">
                    <p>Description: {{$book->description}}</p>
                    <ul style="list-style-type: none;">
                      <li style="float: left; padding: 3px;"><div class="buy_now_button"><button class="btn btn-primary"><a style="color: white"  href="{{ route('admin.edit',$book->id)}}">Edit</a></button></div></li>
                      <li style="float: left; padding: 3px;"><form action="{{ route('admin.destroy', $book->id)}}" method="post">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger" type="submit">Delete</button>
                  </li>
                      
                    </ul>
                <br><br>
                 <br>
                </div>
                </li>
                  </ul>
                @endforeach
                <div class="cleaner">&nbsp;</div>
            </div>
 </div>
 @endsection