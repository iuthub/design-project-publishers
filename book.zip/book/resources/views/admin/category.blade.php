@extends('admin/index')
@section('content')
<br>
	<div class="container">

    <form method="POST" action="{{ route('category.store') }}" role="form" enctype="multipart/form-data">

        {{ csrf_field() }}

       <div>
          <label >Category Name</label>
          <input type="text" name="name" placeholder="Category Name">
          <br>
          <input type="submit" name="submit"/>

      </div>
      <div>

@endsection


