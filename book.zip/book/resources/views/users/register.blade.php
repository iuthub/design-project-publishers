<html>
<link href="{{asset('css/app.css')}}" rel="stylesheet" type="text/css" />
<body>
  
<div class="login-page one">
	<h1 style="margin-left: 30px;">Welcome to registeration part</h1>
  <div class="form">
    <h1 style="color: black">Registration</h1>
    <form class="login-form"  action="/register" method="POST">
    	 {{ csrf_field() }}
      <input type="text" placeholder="name" id="name" name="name"/>
      <input type="text" placeholder="email" id="email" name="email"/>
      <input type="password" placeholder="password" id="password" name="password"/>
      <input type="submit" name="login"/>
    </form>
  </div>
</div>

</body>
</html>