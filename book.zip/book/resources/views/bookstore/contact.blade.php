@extends('bookstore/base')
@section('content')


    <div class="row input-container">
        <ul style="list-style-type: none;">
            <li style="float: left;">
                <div class="col-xs-12">
                <div class="styled-input wide" style="padding: 10px; ">
                                 <label class="label" style="margin-left: 80px" >Name</label>        
                    <input class="input" type="text" required style="border-radius: 10px; padding-left: 10px; margin-left: 10px"  />

                </div>
            </div>
           
            </li>
            <li>
             <div class="col-md-6 col-sm-12">
                <div class="styled-input" style="padding: 10px;">
                    <label class="label" style="margin-left: 80px">Email</label>
                    <input type="text" class="input" required style="border-radius: 10px; padding-left: 10px; margin-left: 10px"/>
                     
                </div>
            </div>   
            </li>
        </ul>
             
            <div class="col-xs-12">
                <div class="styled-input wide">
                    <label class="label" style="margin-left: 130px"></label>
                    <textarea class="textarea" placeholder="Message" style="width: 450px;height:150px;  padding: 10px; border-radius: 10px;" required></textarea>
                    
                </div>
            </div>
            <div class="col-xs-12">
                <div class="btn-lrg submit-btn"><button style="margin-left: 490px; margin-top: 15px; border-radius: 5px" > Send Message</button></div>
                
            </div>
    </div>
</div>




@endsection




