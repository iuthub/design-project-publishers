@extends('bookstore/base')
@section('content')
  <div id="templatemo_content_right">
            <div class="templatemo_product_box">
                <h1>{{$books[0]->name}}  <span>{{$books[0]->author}}</span></h1>
          <img src="uploads/{{$books[0]->profile_image}}" alt="image" />
                <div class="product_info">s
                    <p>{{$books[0]->description}}</p>
                    <br>
                    <div class="buy_now_button"><a href="uploads/bookfile/{{$books[0]->file}}" download>Download</a></div>
                     <div class="detail_button"><a href="/detail/{{$books[0]->id}}">Detail</a></div>
                    
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1>{{$books[1]->name}}  <span>{{$books[1]->author}}</span></h1>
            <img src="uploads/{{$books[1]->profile_image}}" alt="image" />
                <div class="product_info">
                    <p>{{$books[1]->description}}.</p>
                    <div class="buy_now_button"><a href="uploads/bookfile/{{$books[1]->file}}"download>Download</a></div>
                    <div class="detail_button"><a href="/detail/{{$books[0]->id}}">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <div class="templatemo_product_box">
                
                <h1>{{$books[2]->name}} <span>{{$books[2]->author}}</span></h1>
          <img src="uploads/{{$books[2]->profile_image}}" alt="image" />
                <div class="product_info">
                    <p>{{$books[2]->description}}</p>
                    <div class="buy_now_button"><a href="uploads/bookfile/{{$books[2]->file}}" download>Download</a></div>
                    <div class="detail_button"><a href="/detail/{{$books[0]->id}}">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
       
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1>S{{$books[3]->name}}  <span>{{$books[3]->author}}</span></h1>
                <img src="uploads/{{$books[3]->profile_image}}" alt="image" />
                <div class="product_info">
                    <p>{{$books[3]->description}} </p>
                    <div class="buy_now_button"><a href="uploads/bookfile/{{$books[3]->file}}" download>Download</a></div>
                    <div class="detail_button"><a href="/detail/{{$books[0]->id}}">Detail</a></div>
                </div>

                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
         
           
        </div>
@endsection