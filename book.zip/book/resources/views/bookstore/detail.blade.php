@extends('bookstore/base')
@section('content')
  <div id="templatemo_content_right">
        	
            <h1>{{$book->name}}<span>(by author name)</span></h1>
            <div class="image_panel"><img src="../uploads/{{$book->profile_image}}" alt="image" /></div>
            <ul>
              
	            <li>By  <a href="#">{{$book->author}}</a></li>
                <li>Pages: {{$book->page_number}}</li>
                <li>ISBN : {{$book->isbn_number}}</li>
            </ul>
            
           <p>{{$book->description}}</p>
            
             <div class="cleaner_with_height">&nbsp;</div>
            
        </div>




@endsection