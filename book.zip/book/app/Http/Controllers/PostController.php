<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Book;
use \Input as Input;


class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
 
    public function index()
    {
        $books = Book::all();
        return view('admin.home', compact('books'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
       'file' => 'required',
       'file' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
      ]);
        $book= new Book();

        $book->name = request('name');
        $book->description = request('description');
        $book->year = request('year');
        $book->cost = request('cost');
        $book->author = request('author');
        $book->page_number = request('page_number');
        $book->isbn_number = request('isbn_number');
        $book->category_id = request('category_id');
        if($request->hasfile('file')) {
            $image = $request->file('file');
            $name=$image->getClientOriginalName();
            $image->move(public_path().'/uploads/', $name); 
            $book->profile_image = $name; 
        }
        if($request->hasfile('bookfile')) {
            $bookfile = $request->file('bookfile');
            $name=$bookfile->getClientOriginalName();
            $bookfile->storePubliclyAs('bookfile',$name, 'public' );
            $book->file = $name; 
        }
       
       
      


    
        $book->save();

        return redirect('/admin')->with('success', 'Contact saved!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $book = Book::find($id);
        return view('admin.edit', compact('book'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $request->validate([
            'name'=>'required',
            'description'=>'required',
            
        ]);
        $book = Book::find($id);
        $book->name   = $request->get('name');
        $book->description   = $request->get('description');
        $book->author = $request->get('author');
        $book->isbn_number      = $request->get('isbn_number');
        $book->cost          = $request->get('cost');
        $book->page_number      = $request->get('page_number');
        $book->year    = $request->get('year');
        
    
        $book->save();
        return redirect('/admin')->with('success', 'Contact updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $book = Book::find($id);
        $book->delete();

        return redirect('/admin')->with('success', 'Contact deleted!');
    }
    
}
