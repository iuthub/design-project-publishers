<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Book extends Model
{      
	   protected $table = "books";
       protected $fillable = [
        'name',
        'description', 
        'cost',
        'author',
        'page_number',
        'isbn_number',
        'year',
        'profile_image',
        'file',
        'category_id',
     ];
     
     public function getImageAttribute() {
         return $this->profile_image;
     }

    public function category_id()
    {
        return $this->belongsTo('App\Category', 'category_id');
    }

     
}
