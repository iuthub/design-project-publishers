<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBooksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
           $table->bigIncrements('id');
            $table->timestamps();
            $table->string('name');
            $table->mediumText('description');
            $table->string('author');
            $table->string('isbn_number');
            $table->string('cost');
            $table->string('page_number');
            $table->string('year');
            $table->string('profile_image')->nullable();
            $table->string('file')->nullable();
            $table->string('category_id')->nullable();
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function  down()
    {
        Schema::dropIfExists('books');
    }
}
