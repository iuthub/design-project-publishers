<?php $__env->startSection('content'); ?>
<br>
	<div class="container">

    <form method="POST" action="<?php echo e(route('category.store')); ?>" role="form" enctype="multipart/form-data">

        <?php echo e(csrf_field()); ?>


       <div>
          <label >Category Name</label>
          <input type="text" name="name" placeholder="Category Name">
          <br>
          <input type="submit" name="submit"/>

      </div>
      <div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/admin/category.blade.php ENDPATH**/ ?>