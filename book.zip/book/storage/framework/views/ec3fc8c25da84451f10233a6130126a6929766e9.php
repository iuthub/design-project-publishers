<?php $__env->startSection('content'); ?>
<br>
<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<hr>
                <h3>Category name: <?php echo e($cat->name); ?> </h3>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/admin/allcategoty.blade.php ENDPATH**/ ?>