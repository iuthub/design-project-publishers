</<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
   
</head>
<body>

<h1>Edit New Books</h1>

<div class="container">

    <form method="POST" action="<?php echo e(route('admin.update', $book->id)); ?>">
        <?php echo method_field('PATCH'); ?> 
            <?php echo csrf_field(); ?>

       <div>
          <label >Book Name</label>
          <input type="text" name="name" value="<?php echo e($book->name); ?>"/>

      </div>
      <div>
            <label >Book Description</label>
            <input  type="text" name="description" value="<?php echo e($book->description); ?>"/>

      </div>
      <div>
          <label >Book Author</label>
          <input type="text"  name="author" value= "<?php echo e($book->author); ?>"/>

      </div>
      <div>
          <label >Book cost</label>
          <input type="text" name="cost" value= "<?php echo e($book->cost); ?>" />

      </div>
      <div>
          <label >Book page_number</label>
          <input type="text" name="page_number" value=" <?php echo e($book->page_number); ?>" />

      </div>
      <div>
          <label >Book isbn_number</label>
          <input type="text"  name="isbn_number" value=" <?php echo e($book->isbn_number); ?>" />

      </div>
      <div>
          <label >Book year</label>
          <input type="text" name="year" value=" <?php echo e($book->year); ?>" />

      </div>
      <div>

            <input type="submit" value="Update"/>

      </div>

    </form>  

 </div>   

</body>
</html><?php /**PATH /home/dilshod/Desktop/book/resources/views/admin/edit.blade.php ENDPATH**/ ?>