<?php $__env->startSection('content'); ?>
  <div class="container">
  <div id="templatemo_content_right">
            <div class="templatemo_product_box">
              <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h6 style="margin-left: 40px">Book NAme: <?php echo e($book->name); ?> <br> <span> Author: <?php echo e($book->author); ?></span></h6>
                  <ul style=" list-style-type: none;">
                    <li style="float: left; padding-right: 10px"> <img src="uploads/<?php echo e($book->profile_image); ?>" alt="image" />
                    </li>
                    <li><div class="product_info">
                    <p>Description: <?php echo e($book->description); ?></p>
                    <ul style="list-style-type: none;">
                      <li style="float: left; padding: 3px;"><div class="buy_now_button"><button class="btn btn-primary"><a style="color: white"  href="<?php echo e(route('admin.edit',$book->id)); ?>">Edit</a></button></div></li>
                      <li style="float: left; padding: 3px;"><form action="<?php echo e(route('admin.destroy', $book->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                  </li>
                      
                    </ul>
                <br><br>
                 <br>
                </div>
                </li>
                  </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="cleaner">&nbsp;</div>
            </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/admin/home.blade.php ENDPATH**/ ?>