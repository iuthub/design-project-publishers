<?php $__env->startSection('content'); ?>
  <div id="templatemo_content_right">
            <div class="templatemo_product_box">
                <h1>Photography  <span>(by Best Author)</span></h1>
          <img src="<?php echo e(asset('images/templatemo_image_01.jpg')); ?>" alt="image" />
                <div class="product_info">
                    <p>Etiam luctus. Quisques facilisis suscipit elit. Curabitur...</p>
                  <h3>$55</h3>
                    <div class="buy_now_button"><a href="subpage.html">Download</a></div>
                    <div class="detail_button"><a href="/detail/">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1>Cooking  <span>(by New Author)</span></h1>
            <img src="<?php echo e(asset('images/templatemo_image_02.jpg')); ?>" alt="image" />
                <div class="product_info">
                    <p>Aliquam a dui, ac magna quis est eleifend dictum.</p>
                    <h3>$35</h3>
                  <div class="buy_now_button"><a href="subpage.html">Download</a></div>
                    <div class="detail_button"><a href="/detail/">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1>Gardening <span>(by Famous Author)</span></h1>
          <img src="<?php echo e(asset('images/templatemo_image_03.jpg')); ?>" alt="image" />
                <div class="product_info">
                    <p>Ut fringilla enim sed turpis. Sed justo dolor, convallis at.</p>
                    <h3>$65</h3>
                    <div class="buy_now_button"><a href="subpage.html">Download</a></div>
                    <div class="detail_button"><a href="/detail/">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1>Sushi Book  <span>(by Japanese Name)</span></h1>
                <img src="<?php echo e(asset('images/templatemo_image_04.jpg')); ?>" alt="image" />
                <div class="product_info">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                    <h3>$45</h3>
                    <div class="buy_now_button"><a href="subpage.html">Download</a></div>
                    <div class="detail_button"><a href="/detail/">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
           
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bookstore/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/bookstore/free.blade.php ENDPATH**/ ?>