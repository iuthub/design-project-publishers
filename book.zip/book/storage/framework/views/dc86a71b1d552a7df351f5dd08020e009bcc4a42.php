<?php $__env->startSection('content'); ?>
  <div id="templatemo_content_right">
            <div class="templatemo_product_box">
                <h1><?php echo e($books[0]->name); ?>  <span><?php echo e($books[0]->author); ?></span></h1>
          <img src="uploads/<?php echo e($books[0]->profile_image); ?>" alt="image" />
                <div class="product_info">s
                    <p><?php echo e($books[0]->description); ?></p>
                    <br>
                    <div class="buy_now_button"><a href="uploads/bookfile/<?php echo e($books[0]->file); ?>" download>Download</a></div>
                     <div class="detail_button"><a href="/detail/<?php echo e($books[0]->id); ?>">Detail</a></div>
                    
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1><?php echo e($books[1]->name); ?>  <span><?php echo e($books[1]->author); ?></span></h1>
            <img src="uploads/<?php echo e($books[1]->profile_image); ?>" alt="image" />
                <div class="product_info">
                    <p><?php echo e($books[1]->description); ?>.</p>
                    <div class="buy_now_button"><a href="uploads/bookfile/<?php echo e($books[1]->file); ?>"download>Download</a></div>
                    <div class="detail_button"><a href="/detail/<?php echo e($books[0]->id); ?>">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <div class="templatemo_product_box">
                
                <h1><?php echo e($books[2]->name); ?> <span><?php echo e($books[2]->author); ?></span></h1>
          <img src="uploads/<?php echo e($books[2]->profile_image); ?>" alt="image" />
                <div class="product_info">
                    <p><?php echo e($books[2]->description); ?></p>
                    <div class="buy_now_button"><a href="uploads/bookfile/<?php echo e($books[2]->file); ?>" download>Download</a></div>
                    <div class="detail_button"><a href="/detail/<?php echo e($books[0]->id); ?>">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
       
            
            <div class="cleaner_with_width">&nbsp;</div>
            
            <div class="templatemo_product_box">
                <h1>S<?php echo e($books[3]->name); ?>  <span><?php echo e($books[3]->author); ?></span></h1>
                <img src="uploads/<?php echo e($books[3]->profile_image); ?>" alt="image" />
                <div class="product_info">
                    <p><?php echo e($books[3]->description); ?> </p>
                    <div class="buy_now_button"><a href="uploads/bookfile/<?php echo e($books[3]->file); ?>" download>Download</a></div>
                    <div class="detail_button"><a href="/detail/<?php echo e($books[0]->id); ?>">Detail</a></div>
                </div>

                <div class="cleaner">&nbsp;</div>
            </div>
            
            <div class="cleaner_with_height">&nbsp;</div>
         
           
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bookstore/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/bookstore/index.blade.php ENDPATH**/ ?>