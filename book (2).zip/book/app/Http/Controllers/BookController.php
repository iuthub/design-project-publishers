<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Book;
use App\Category;

class BookController extends Controller
{
    public function index() {
    	$books =  Book::all();
        $categories = Category::all();
        return view('bookstore.index', compact('books', 'categories'));
    }
    public function login() {
        $categories = Category::all();
    	return view('bookstore/login',  compact('categories'));
    }
    public function contact() {
        $categories = Category::all();
    	return view('bookstore/contact', compact('categories'));
    }
    public function free() {
    	return view('bookstore/free');
    }
    public function detail($id) {
        $book = Book::find($id);
        $categories = Category::all();
        return view('bookstore.detail', compact('book', 'categories'));
    }
    // public function category() {
    //     $categories = Category::all();
    //     return view('bookstore.base', compact('categories'));
    // }
    public function adminhome() {
        return view('admin.index');
    }
}
