@extends('admin/index')
@section('content')
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
   
</head>
<body>

<div class="container">

<h1>Create New Books</h1>

    <form method="POST" action="{{ route('admin.store') }}" role="form" enctype="multipart/form-data">

        {{ csrf_field() }}

       <div>
          <label >Book Name</label>
          <input type="text" name="name" placeholder="Book Name">

      </div>
      <div>
            <label >Book Description</label>
            <textarea name="description" placeholder="Book Description"></textarea>

      </div>
      <div>
          <label >Book Author</label>
          <input type="text" name="author" placeholder="Book Author">

      </div>
      <div>
          <label >Book cost</label>
          <input type="text" name="cost" placeholder="Book Cost">

      </div>
      <div>
          <label >Book page_number</label>
          <input type="text" name="page_number" placeholder="Book page_number">

      </div>
      <div>
          <label >Book isbn_number</label>
          <input type="text" name="isbn_number" placeholder="Book isbn_number">

      </div>
      <div>
          <label >Book year</label>
          <input type="text" name="year" placeholder="Book year">

      </div>
      <div>
          <label >Book Category</label>
          <input type="text" name="category_id" placeholder="Book Category">

      </div>
       <br>
       <ul style="list-style-type: none;">
         <li style="float: left;"><div class="form-group row">
          <label for="profile_image" class="col-md-4 col-form-label text-md-right">Profile Image</label>
          <div class="col-md-6">
          <input id="file" type="file" name="file">
          </div>
      </li>
         <li><div>
        <label>File</label>
        <input type="file" name="bookfile" id="bookfile">

            <input type="submit" value="Add Book">

      </div>
</li>
       </ul>
                                          
      
    </form>  

 </div>   
 @endsection