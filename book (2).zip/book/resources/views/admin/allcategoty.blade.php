<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		@foreach($category as $cat)
                <h3>Book Titel: {{$cat->name}} </h3>
                @endforeach

</body>
</html>