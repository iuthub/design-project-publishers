<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="{{asset('images/templatemo_image_04.jpg')}}" itemprop='image' />
<title>Book Shop</title>
<meta name="keywords" content="Book shop" />
<meta name="description" content="Book shop" />
	<link href="{{asset('css/app.css')}}" rel="stylesheet" type="text/css" />
      <link rel = "icon" href =  "https://img.icons8.com/color/48/000000/literature.png" 
        type = "image/x-icon">
</head>
<body>
    
<!--  Free CSS Templates from www.templatemo.com -->
<div id="templatemo_container">

	<div id="templatemo_menu">
    	<ul>
            <li><a href="/" class="current">Home</a></li>     
             <li><a href="/contact/">Contact Us</a></li>
    	</ul>
    </div> <!-- end of menu -->
    
    <div id="templatemo_header">
    	<div id="templatemo_special_offers">
        	 </div>
    </div> <!-- end of header -->
    
    <div id="templatemo_content">
    	
        <div id="templatemo_content_left">
        	<div class="templatemo_content_left_section">
            	<h1>Categories</h1>
                @foreach($categories as $category)
                <ul>
                    <li><a href="subpage.html">{{$category->name}}</a></li>
            	</ul>
                @endforeach
            </div>
			<div class="templatemo_content_left_section">
            	<h1>Bestsellers</h1>
                <ul>
                    <li><a href="#">Math</a></li>
                    <li><a href="#">Math</a></li>
                    <li><a href="#">Math</a></li>
                    <li><a href="#">Math</a></li>

                    
            	</ul>
            </div>
     
     
        </div> <!-- end of content left -->
        
               @yield('content')
            
    
    	<div class="cleaner_with_height">&nbsp;</div>
    </div> <!-- end of content -->
    
    
    <!-- end of footer -->
<!--  Free CSS Template www.templatemo.com -->
</div> <!-- end of container -->

</body>
</html>