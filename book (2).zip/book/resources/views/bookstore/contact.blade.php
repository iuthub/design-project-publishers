@extends('bookstore/base')
@section('content')


    <div class="row input-container">
            <div class="col-xs-12">
                <div class="styled-input wide">
                    <input class="input" type="text" required />
                    <label class="label">Name</label> 
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="styled-input">
                    <input type="text" class="input" required />
                    <label class="label">Email</label> 
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="styled-input" style="float:right;">
                    <input type="text" class="input" required />
                    <label class="label">Phone Number</label> 
                </div>
            </div>
            <div class="col-xs-12">
                <div class="styled-input wide">
                    <textarea class="textarea" required></textarea>
                    <label class="label">Message</label>
                </div>
            </div>
            <div class="col-xs-12">
                <div class="btn-lrg submit-btn">Send Message</div>
            </div>
    </div>
</div>




@endsection