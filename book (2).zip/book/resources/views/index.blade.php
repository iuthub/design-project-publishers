<html>
<link href="{{asset('css/app.css')}}" rel="stylesheet" type="text/css" />
<body>
  
<div class="login-page one">
	<h1 style="margin-left: 30px;">Welcome to free book shop</h1>
  <div class="form">
    <form class="login-form"  action="loginman" method="POST">
    	 {{ csrf_field() }}
    	 

      <input type="text" placeholder="name" id="name" name="name"/>
      <input type="password" placeholder="password" id="password" name="password"/>
      <input type="submit" name="login"/>
      <p class="message">Not registered? <a href="/register ">Create an account</a></p>
    </form>
  </div>
</div>

</body>
</html>
 