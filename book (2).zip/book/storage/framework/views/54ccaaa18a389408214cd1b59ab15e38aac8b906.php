<html>
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" />
<body>
  
<div class="login-page one">
	<h1 style="margin-left: 30px;">Welcome to registeration part</h1>
  <div class="form">
    <h1 style="color: black">Registration</h1>
    <form class="login-form"  action="/register" method="POST">
    	 <?php echo e(csrf_field()); ?>

      <input type="text" placeholder="name" id="name" name="name"/>
      <input type="text" placeholder="email" id="email" name="email"/>
      <input type="password" placeholder="password" id="password" name="password"/>
      <input type="submit" name="login"/>
    </form>
  </div>
</div>

</body>
</html><?php /**PATH /home/dilshod/Desktop/book/resources/views/users/register.blade.php ENDPATH**/ ?>