<?php $__env->startSection('content'); ?>


    <div class="row input-container">
            <div class="col-xs-12">
                <div class="styled-input wide">
                    <input class="input" type="text" required />
                    <label class="label">Name</label> 
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="styled-input">
                    <input type="text" class="input" required />
                    <label class="label">Email</label> 
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="styled-input" style="float:right;">
                    <input type="text" class="input" required />
                    <label class="label">Phone Number</label> 
                </div>
            </div>
            <div class="col-xs-12">
                <div class="styled-input wide">
                    <textarea class="textarea" required></textarea>
                    <label class="label">Message</label>
                </div>
            </div>
            <div class="col-xs-12">
                <div class="btn-lrg submit-btn">Send Message</div>
            </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('bookstore/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/bookstore/contact.blade.php ENDPATH**/ ?>