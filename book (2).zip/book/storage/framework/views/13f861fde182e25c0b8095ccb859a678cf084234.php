<?php $__env->startSection('content'); ?>
  <div id="templatemo_content_right">
        	
            <h1><?php echo e($book->name); ?><span>(by author name)</span></h1>
            <div class="image_panel"><img src="../uploads/<?php echo e($book->profile_image); ?>" alt="image" /></div>
            <ul>
              
	            <li>By  <a href="#"><?php echo e($book->author); ?></a></li>
                <li>Pages: <?php echo e($book->page_number); ?></li>
                <li>ISBN : <?php echo e($book->isbn_number); ?></li>
            </ul>
            
           <p><?php echo e($book->description); ?></p>
            
             <div class="cleaner_with_height">&nbsp;</div>
            
        </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('bookstore/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilshod/Desktop/book/resources/views/bookstore/detail.blade.php ENDPATH**/ ?>