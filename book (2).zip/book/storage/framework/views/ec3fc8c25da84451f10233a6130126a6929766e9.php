<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3>Book Titel: <?php echo e($cat->name); ?> </h3>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH /home/dilshod/Desktop/book/resources/views/admin/allcategoty.blade.php ENDPATH**/ ?>