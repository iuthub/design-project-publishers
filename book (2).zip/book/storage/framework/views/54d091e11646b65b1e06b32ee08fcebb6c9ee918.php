<!DOCTYPE html>
<html>
<head>
	<title>
		Create Category
	</title>
</head>
<body>

	<div class="container">

    <form method="POST" action="<?php echo e(route('category.store')); ?>" role="form" enctype="multipart/form-data">

        <?php echo e(csrf_field()); ?>


       <div>
          <label >Book Name</label>
          <input type="text" name="name" placeholder="Category Name">
          <br>
          <input type="submit" name="submit"/>

      </div>
      <div>

</body>
</html>


<?php /**PATH /home/dilshod/Desktop/book/resources/views/admin/category.blade.php ENDPATH**/ ?>